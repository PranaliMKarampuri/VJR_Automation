# Final Stage 1 accuracy report

## Record disposition

| Metric | Result |
|---|---:|
| TOTAL_RECORDS | 661 |
| WRITTEN_RECORDS (at least one output cell) | 497 |
| ZERO_WRITE_RECORDS | 164 |
| UNSUPPORTED_RECORDS | 24 |
| CELLS_WRITTEN | 1210 |

Output: `output/TAKEOFF_CS_KATIVIK_VJR.xlsx`. No real mapping, transformation, unit-conversion, or aggregation error was established in this audit; no writer change was justified. The output was regenerated from the current writer. Current comparison and audit files were regenerated with it.

## 25_DIFFERENCES

| Classification | Count | Finding |
|---|---:|---|
| COMPARISON_ARTIFACT | 18 | Same-size candidates do not have Unit/Label identity; no unique source-to-reference pairing can be asserted. |
| REFERENCE_PROJECT_SPECIFIC | 7 | The remaining same-size Reference example differs, while Manual totals/rules support the generated grouping/value. |
| Fixed by code after this review | 0 | No evidence-backed writer defect was found to fix. |
| REAL_MAPPING_ERROR / REAL_TRANSFORMATION_ERROR / REAL_UNIT_ERROR / REAL_AGGREGATION_ERROR | 0 | No evidence-backed writer defect found. |
| unresolved identity | 18 | These pairings stay explicitly unverified because Reference rows omit Unit/Label. |

The seven single-candidate comparisons are still Reference examples, not authoritative corrections to this Manual. Differences include nonmatching lengths/accessory slots and Reference-only material/type values. The row-by-row source, output/reference cells, and exact differences are in `final_stage1_record_review.csv` and `output/TAKEOFF_CS_KATIVIK_reference_comparison.csv`.

## 164_ZERO_WRITE

| Classification | Count |
|---|---:|
| SHOULD_BE_AUTOMATED after this review | 0 |
| GENUINELY_MISSING_SOURCE_DATA | 140 |
| GENUINELY_UNSUPPORTED | 24 |

All 164 are itemized with available Manual fields, PPT rule, destination status, calculability, and reason in `final_stage1_record_review.csv`. Known codes are not treated as unknown: T-vane (7/71), canvas (8), mesh (14/141), and documented damper codes are already implemented when their destination association is unique. Remaining zero writes lack the required flex product/block, riser drop, unique duct association/route, or a documented mapping. Unsupported cases total 24.

## 93_REFERENCE_NOT_PRESENT

| Classification | Count |
|---|---:|
| VALID_WITHOUT_REFERENCE | 51 |
| NEEDS_SOURCE_DATA | 42 |
| UNSUPPORTED | 0 |
| POSSIBLE_MAPPING_ERROR | 0 |

These rows are not forced to match the incomplete Reference. Spiral/elbow quantities are Manual-derived. The TAKE OFF rows are Manual-derived; pressure remains missing for rows whose source group is already flagged for absent BP/MP/HP. This separates valid written values from missing fields.

## TOTAL_SOURCE_RECONCILIATION

| Stream | Manual source | Generated output | Result |
|---|---:|---:|---|
| Rectangular duct length | 1151.7 m | 1151.7 m | Reconciles |
| Spiral duct length | 863.4 ft | 863.4 ft | Reconciles |
| 45? + 90? elbows | 172 count | 172 count | Reconciles; angles kept in separate columns |
| Flex | 73 counts; rule implies 365 ft | 0 ft written | Not placed: product/block missing |
| Risers | 21 records | 2 records, 9.17 m | Two unique Reference-supported lengths; 19 lack positive drop length; direction also absent on the two partial records |
| T-vane accessories | 90 source count | 60 generated; 30 unresolved | Reconciles; PPT code 7/71; unresolved association cases itemized |
| Canvas accessories | 21 source count | 13 generated; 8 unresolved | Reconciles; PPT code 8; unresolved association cases itemized |
| Mesh accessories | 11 source count | 4 generated; 7 unresolved | Reconciles; PPT code 14/141; unresolved route/association cases itemized |
| Dampers | 100 source count | 35 generated; 65 unresolved/unsupported | Reconciles; PPT-known codes written; remaining rows itemized |
| Embedded rectangular accessories | 48 Manual rows with 1-inch acoustic insulation | 48 code-21 entries written | Reconciles to PPT slide 26; all other code entries are traceable in the ledger |

## Write-cell audit and workbook preservation

The complete unique-cell ledger contains **1210 rows** (all 1209 source-linked cells plus global selector TAKE OFF!N4). Every output value was read back and matched the audit value; all target cells are in known template input columns, and no emitted target is a formula cell. Cell check failures: **0**.

Validation package checks report: calculation formulas modified **0**; formulas, formatting, merged cells, validations, drawings, named ranges, sheets, and package structure preserved. Source Manual, clean template, and Reference hashes are unchanged (see `output/TAKEOFF_CS_KATIVIK_VJR_validation_report.md`).

## Final verdict: READY_WITH_EXPLICIT_UNRESOLVED_CASES

Automated values are traceable through the write ledger to Manual source rows and rule sources. The output is not declared 100% accurate: 164 zero-write records remain, 160 rectangular records lack pressure classification, and Reference identity is unprovable for ambiguous rows. The test suite passed 10 focused tests. No additional writer change was made because this review found no concrete error that can be corrected from the supplied evidence without guessing.

### Audit artifacts

- Write ledger: `reports/final_stage1_write_ledger.csv`
- Record-level review: `reports/final_stage1_record_review.csv`
- Current normalized comparison: `output/TAKEOFF_CS_KATIVIK_reference_comparison.csv`
- Record audit / unresolved list: `output/TAKEOFF_CS_KATIVIK_record_audit.csv`, `output/TAKEOFF_CS_KATIVIK_unresolved.csv`
- Validation: `output/TAKEOFF_CS_KATIVIK_VJR_validation_report.md`
