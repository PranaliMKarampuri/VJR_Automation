# TAKEOFF_CS_KATIVIK → VJR validation

## Run totals

- Total CSV records: **661**
- Records processed: **661**
- Records with at least one populated input: **497**
- Records aggregated into an existing group: **270**
- Unsupported records: **24**
- Records with review items (including partially populated): **302**
- Records entirely skipped for review: **140**
- Cells written: **1210**
- Pressure types inferred from a unique matching Reference row: **19**
- Riser records populated from a unique same-size Reference row: **2**
- Row-level audit: `C:\Users\91739\Desktop\VJR_Automation\output\TAKEOFF_CS_KATIVIK_record_audit.csv`
- Unresolved records/fields: `C:\Users\91739\Desktop\VJR_Automation\output\TAKEOFF_CS_KATIVIK_unresolved.csv`
- Reference comparison: `C:\Users\91739\Desktop\VJR_Automation\output\TAKEOFF_CS_KATIVIK_reference_comparison.csv`

## Source/VJR reconciliation

- Rectangular Manual length total: **1151.7**; grouped/planned TAKE OFF total: **1151.7** (unit preserved per source row).
- Riser length imported from unique Reference matches: **9.17 m**; unmatched risers remain unresolved for missing project drop/direction data.
- Spiral Manual length total: **863.4**; grouped/planned SPIRALE total: **863.4**.
- Elbow Manual count total: **172**; grouped/planned 45°/90° count: **172**.
- Flex: **73** source count; not written where product block is unspecified.
- Accessory counts are represented as repeated PPT codes in TAKE OFF G:J; continuation rows repeat size and use length zero.

## Reference comparison

- Exact generated TAKE OFF rows matching Reference values: **20**.
- Comparison classifications: **{'DIFFERENCE': 25, 'NOT_PRESENT_IN_REFERENCE': 93, 'MATCH': 20}**.
- The Reference has no Unit/Label fields, so exact project identity cannot be proven from row values alone.
- Every non-match and its field-level difference/reason is in the comparison CSV.

| Input | SHA-256 before generation | SHA-256 after generation |
|---|---|---|
| CSV | `342fbaf5d6dfd44c3f2c20a195a4679156f66adf83de4f3bd525f0752857c66e` | `342fbaf5d6dfd44c3f2c20a195a4679156f66adf83de4f3bd525f0752857c66e` |
| template | `a6775a49eb639efd3e3d34805ee2091dd5305cbd839a2ceccb8aa1c053cdcea8` | `a6775a49eb639efd3e3d34805ee2091dd5305cbd839a2ceccb8aa1c053cdcea8` |
| Reference VJR | `54f2bbdd2a89a196d3fdf29a8c8238694cbc49f11ecde9bda2c9aa8a86894500` | `54f2bbdd2a89a196d3fdf29a8c8238694cbc49f11ecde9bda2c9aa8a86894500` |

## Template integrity

- Source template used as base; workbook structure was not recreated.
- PASS: Workbook package membership and untouched package parts verified.
- PASS: All calculation formulas preserved; formula differences are limited to explicitly populated carry-forward input cells.
- PASS: Input styles, merged cells, validations, drawings, and worksheet structure preserved.
- Calculation formulas modified: **0**; carry-forward input formulas replaced on allocated rows: **590**.
- Original CSV/template/Reference hashes unchanged.

## Errors and warnings

- CSV parse errors: **0**.
- Unsupported or missing project facts are itemized by source CSV row in the unresolved CSV; other supported records continue through generation.
