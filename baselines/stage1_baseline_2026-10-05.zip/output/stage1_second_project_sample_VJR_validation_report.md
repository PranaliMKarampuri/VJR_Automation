# stage1_second_project_sample → VJR validation

## Run totals

- Total CSV records: **3**
- Records processed: **3**
- Records with at least one populated input: **3**
- Records aggregated into an existing group: **1**
- Unsupported records: **0**
- Records with review items (including partially populated): **0**
- Records entirely skipped for review: **0**
- Cells written: **21**
- Pressure types inferred from a unique matching Reference row: **0**
- Riser records populated from a unique same-size Reference row: **0**
- Row-level audit: `output\stage1_second_project_sample_record_audit.csv`
- Unresolved records/fields: `output\stage1_second_project_sample_unresolved.csv`
- Reference comparison: `output\stage1_second_project_sample_reference_comparison.csv`

## Source/VJR reconciliation

- Rectangular Manual length total: **8.50**; grouped/planned TAKE OFF total: **8.50** (unit preserved per source row).
- Riser length imported from unique Reference matches: **0 m**; unmatched risers remain unresolved for missing project drop/direction data.
- Spiral Manual length total: **0**; grouped/planned SPIRALE total: **0**.
- Elbow Manual count total: **0**; grouped/planned 45°/90° count: **0**.
- Flex: **0** source count; not written where product block is unspecified.
- Accessory counts are represented as repeated PPT codes in TAKE OFF G:J; continuation rows repeat size and use length zero.

## Reference comparison

- Exact generated TAKE OFF rows matching Reference values: **0**.
- Comparison classifications: **{}**.
- The Reference has no Unit/Label fields, so exact project identity cannot be proven from row values alone.
- Every non-match and its field-level difference/reason is in the comparison CSV.

| Input | SHA-256 before generation | SHA-256 after generation |
|---|---|---|
| CSV | `93a8eacd081813bb5e7c6e191bd99a04902bb92457e83ee943f15a024eab92f8` | `93a8eacd081813bb5e7c6e191bd99a04902bb92457e83ee943f15a024eab92f8` |
| template | `a6775a49eb639efd3e3d34805ee2091dd5305cbd839a2ceccb8aa1c053cdcea8` | `a6775a49eb639efd3e3d34805ee2091dd5305cbd839a2ceccb8aa1c053cdcea8` |

## Template integrity

- Source template used as base; workbook structure was not recreated.
- PASS: Workbook package membership and untouched package parts verified.
- PASS: All calculation formulas preserved; formula differences are limited to explicitly populated carry-forward input cells.
- PASS: Input styles, merged cells, validations, drawings, and worksheet structure preserved.
- Calculation formulas modified: **0**; carry-forward input formulas replaced on allocated rows: **5**.
- Original CSV/template/Reference hashes unchanged.

## Errors and warnings

- CSV parse errors: **0**.
- Unsupported or missing project facts are itemized by source CSV row in the unresolved CSV; other supported records continue through generation.
