import csv
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation

import manual_to_vjr as writer


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


class ManualToVjrWriterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.inputs = self.root / "test_input"
        self.outputs = self.root / "output"
        self.inputs.mkdir()
        self.manual = self.inputs / "sample.xlsx"
        self.template = self.inputs / "client_vjr.xlsx"
        self.mapping = self.root / "approved.csv"
        self._manual()
        self._template()

    def tearDown(self):
        self.temp.cleanup()

    def _manual(self, subject="RECT. DUCT M", size="200X300", row_type="BP", label="RECT. DUCT", length_unit="m", accessory1="."):
        book = openpyxl.Workbook()
        ws = book.active
        ws.title = "DATA"
        ws.append(["Subject", "Page Index", "Length", "Length Unit", "Count", "Label", "BRAND", "MODEL", "DUCT SIZE", "TYPE", "ACCESSORIES1", "ACCESSORIES2", "REMARK", "UNITS", "DAMPER TYPE"])
        ws.append([subject, 1, 2.0, length_unit, 0, label, ".", ".", size, row_type, accessory1, ".", ".", "UTA-1", "NO"])
        book.save(self.manual)

    def _template(self, formula_at=None, selector="M"):
        book = openpyxl.Workbook()
        takeoff = book.active
        takeoff.title = "TAKE OFF"
        for name in ("SPIRALE", "ROND ET FLEX"):
            book.create_sheet(name)
        takeoff["N4"] = selector
        for col in "ABCDEFGHIJ":
            cell = takeoff[f"{col}20"]
            cell.number_format = "0.00"
        if formula_at:
            takeoff[formula_at] = "=1+1"
        validation = DataValidation(type="list", formula1='"BP,MP,HP"')
        takeoff.add_data_validation(validation)
        validation.add(takeoff["E20"])
        book.save(self.template)

    def _manifest(self, values=None, row=20, source_row=2):
        values = values or {
            f"A{row}": 300, f"B{row}": 200, f"C{row}": 2.0,
            f"D{row}": 26, f"E{row}": "BP", f"F{row}": "HA",
        }
        with self.mapping.open("w", newline="", encoding="utf-8-sig") as stream:
            fields = list(writer.MANIFEST_HEADERS)
            output = csv.DictWriter(stream, fieldnames=fields)
            output.writeheader()
            output.writerow({
                "manifest_scope": "TEST_ONLY",
                "manual_source_row": source_row,
                "estimator_decision": "SAFE_TO_AUTOMATE",
                "estimator_confirmed_by": "Test Estimator",
                "estimator_confirmation_date": "2026-10-03",
                "ppt_rule": "rectangular",
                "target_sheet": "TAKE OFF",
                "target_row": row,
                "dimension_unit": "mm",
                "write_values_json": json.dumps(values),
            })

    def test_input_discovery_and_filename_resolution(self):
        self.assertEqual(writer.discover_inputs(self.inputs), [self.manual])
        self.assertEqual(writer.resolve_manual("sample.xlsx", self.inputs), self.manual.resolve())

    def test_rejects_missing_data_sheet_or_required_columns(self):
        book = openpyxl.Workbook()
        book.save(self.manual)
        with self.assertRaisesRegex(writer.WriterError, "DATA"):
            writer.inspect_manual(self.manual)

    def test_no_manifest_writes_no_cells_and_copies_template_byte_for_byte(self):
        before_input, before_template = file_hash(self.manual), file_hash(self.template)
        result = writer.run(self.manual, self.template, output_dir=self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 0)
        self.assertEqual(result["counts"]["NEEDS_CONFIRMATION"], 1)
        self.assertEqual(result["written_cells"], 0)
        self.assertEqual(file_hash(result["output"]), before_template)
        self.assertEqual(file_hash(self.manual), before_input)

    def test_writes_only_signed_ppt_checked_empty_input_cells_to_new_copy(self):
        self._manifest()
        before_input, before_template = file_hash(self.manual), file_hash(self.template)
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 1)
        self.assertEqual(result["written_cells"], 6)
        output = openpyxl.load_workbook(result["output"], data_only=False)
        self.assertEqual([output["TAKE OFF"][f"{col}20"].value for col in "ABCDEF"], [300, 200, 2, 26, "BP", "HA"])
        self.assertEqual(len(output["TAKE OFF"].data_validations.dataValidation), 1)
        output.close()
        self.assertEqual(file_hash(self.manual), before_input)
        self.assertEqual(file_hash(self.template), before_template)

    def test_formula_target_blocks_entire_record(self):
        self._template(formula_at="A20")
        self._manifest()
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 0)
        self.assertEqual(result["counts"]["NEEDS_CONFIRMATION"], 1)
        self.assertEqual(file_hash(result["output"]), file_hash(self.template))

    def test_test_only_manifest_is_rejected_outside_test_mode(self):
        self._manifest()
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=False)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 0)
        self.assertEqual(file_hash(result["output"]), file_hash(self.template))

    def test_exact_36_inches_stays_needs_confirmation(self):
        self._manual(subject="RECT. DUCT FT", size="36X20", length_unit="ft")
        self._template(selector="A")
        self._manifest({"A20": 36, "B20": 20, "C20": 2.0, "D20": 22, "E20": "BP", "F20": "RE"})
        with self.mapping.open(encoding="utf-8-sig", newline="") as stream:
            values = next(csv.DictReader(stream))
        values["dimension_unit"] = "inch"
        with self.mapping.open("w", newline="", encoding="utf-8-sig") as stream:
            output = csv.DictWriter(stream, fieldnames=list(writer.MANIFEST_HEADERS))
            output.writeheader()
            output.writerow(values)
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 0)
        self.assertEqual(result["counts"]["NEEDS_CONFIRMATION"], 1)

    def test_wrong_accessory_code_is_not_written(self):
        self._manifest({"A20": 300, "B20": 200, "C20": 2.0, "D20": 26, "E20": "BP", "F20": "HA", "G20": 999})
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 0)
        self.assertEqual(file_hash(result["output"]), file_hash(self.template))

    def test_explicit_one_inch_acoustic_insulation_uses_ppt_code_21(self):
        self._manual(accessory1='w/ 1" ACOUSTIC INSULATION')
        self._manifest({"A20": 300, "B20": 200, "C20": 2.0, "D20": 26, "E20": "BP", "F20": "HA", "G20": 21})
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["SAFE_TO_AUTOMATE"], 1)
        book = openpyxl.load_workbook(result["output"], data_only=False)
        self.assertEqual(book["TAKE OFF"]["G20"].value, 21)
        book.close()

    def test_unsupported_source_record_is_never_promoted_or_written(self):
        self._manual(subject="VENT CAP", size="150", row_type=".", label="VENT CAP")
        self._manifest()
        result = writer.run(self.manual, self.template, self.mapping, self.outputs, test_mode=True)
        self.assertEqual(result["counts"]["UNSUPPORTED"], 1)
        self.assertEqual(result["written_cells"], 0)
        self.assertEqual(file_hash(result["output"]), file_hash(self.template))


if __name__ == "__main__":
    unittest.main()
