import csv
import hashlib
import tempfile
import unittest
from pathlib import Path

import openpyxl

import manual_csv_to_vjr
import manual_to_vjr


ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "source_files" / "Ventilation Jean Roy excel.xlsx"


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class ManualCsvPipelineTests(unittest.TestCase):
    def _csv(self, path, count):
        headers = [
            "Subject", "Page Index", "Length", "Length Unit", "Count", "Label",
            "BRAND", "MODEL", "DUCT SIZE", "TYPE", "ACCESSORIES1", "ACCESSORIES2",
            "REMARK", "UNITS", "DAMPER TYPE",
        ]
        records = [
            ["RECT. DUCT M", 1, 1.25, "m", 0, "RECT. DUCT", ".", ".", "300X200", "BP", ".", ".", ".", "SYS-B", "NO"],
            ["RECT. DUCT M", 2, 2.75, "m", 0, "RECT. DUCT", ".", ".", "300X200", "BP", ".", ".", ".", "SYS-B", "NO"],
            ["RECT. DUCT M", 3, 4.5, "m", 0, "RECT. DUCT", ".", ".", "400X200", "HP", ".", ".", ".", "SYS-B", "NO"],
        ][:count]
        with path.open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(headers)
            writer.writerows(records)

    def test_different_record_counts_generate_from_the_supplied_template(self):
        with tempfile.TemporaryDirectory() as temp_name:
            temp = Path(temp_name)
            template_hash = sha256(TEMPLATE)
            result_counts = []
            for count in (2, 3):
                manual = temp / f"manual_{count}.csv"
                output = temp / f"generated_{count}.xlsx"
                report = temp / f"report_{count}.md"
                self._csv(manual, count)
                result = manual_csv_to_vjr.generate(manual, TEMPLATE, output, report)
                result_counts.append(result["records"])
                self.assertEqual(result["records"], count)
                self.assertTrue(output.is_file())
                self.assertTrue(report.is_file())
                book = openpyxl.load_workbook(output, data_only=True, read_only=True)
                template_book = openpyxl.load_workbook(TEMPLATE, read_only=True)
                self.assertEqual(book.sheetnames, template_book.sheetnames)
                template_book.close()
                takeoff = book["TAKE OFF"]
                self.assertEqual(takeoff["N4"].value, "M")
                self.assertEqual(takeoff["C20"].value, 4.0)
                self.assertEqual(takeoff["A21"].value, 400 if count == 3 else None)
                if count == 3:
                    self.assertEqual(takeoff["C21"].value, 4.5)
                book.close()
            self.assertEqual(result_counts, [2, 3])
            self.assertEqual(sha256(TEMPLATE), template_hash)

    def test_csv_engine_has_no_manual_row_or_project_name_gate(self):
        source = Path(manual_csv_to_vjr.__file__).read_text(encoding="utf-8")
        self.assertNotRegex(source, r"KATIVIK|KUUJJAAQ")
        self.assertNotRegex(source, r"source_row\s*==\s*\d+")
        self.assertTrue(callable(manual_csv_to_vjr.generate))
        self.assertTrue(callable(manual_to_vjr.resolve_manual))


if __name__ == "__main__":
    unittest.main()
